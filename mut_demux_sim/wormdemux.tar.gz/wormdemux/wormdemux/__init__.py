"""Demultiplexing pooled single-cell WGS of selfing C. elegans lines."""
from .simulate import simulate_pool, lineage_blocks
from .cluster import (
    carrier_fraction, select_sites, binary_matrices, dist_hamming,
    dist_jaccard, sim_phi, corr_masked, upgma, consensus, assign_em,
    demultiplex, within_cross,
)
from .diagnostics import (
    site_summary, shared_site_stats, plot_carrier_fraction, feasibility_report,
)

__version__ = "0.1.0"
