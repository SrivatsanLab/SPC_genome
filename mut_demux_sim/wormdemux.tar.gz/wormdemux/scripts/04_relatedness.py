#!/usr/bin/env python3
"""How much shared ancestry can two worms have and still be resolved?

Worms separated by few selfing generations share most of their mutations. This
is a hard information limit, not an algorithm failure: beyond ~90% sharing the
pair fuses into one cluster and the honest output is fewer clusters than worms.
"""
from _common import base_parser, header
from sklearn.metrics import adjusted_rand_score
from wormdemux import simulate_pool, demultiplex

SHARING = [0.0, 0.5, 0.9, 0.98]

if __name__ == "__main__":
    p = base_parser(__doc__)
    p.add_argument("--germline", type=int, default=200)
    a = p.parse_args()
    print(header(["sibling sharing", "ARI (K=n_worms)", "ARI (K=n_worms/2)"],
                 [17, 18, 20]))
    for sf in SHARING:
        d = simulate_pool(n_worms=a.worms, cells_per_worm=a.cells,
                          germline_per_worm=a.germline, sibling_shared_frac=sf,
                          breadth=a.breadth, seed=a.seed)
        rK = demultiplex(d["AD"], d["DP"], K=a.worms, frac_lo=0.005)
        rH = demultiplex(d["AD"], d["DP"], K=max(a.worms // 2, 2), frac_lo=0.005)
        clade = d["truth"] // 2                      # true sibling-pair identity
        print(f"{sf:>16.0%}"
              f"{adjusted_rand_score(d['truth'], rK['labels']):>18.3f}"
              f"{adjusted_rand_score(clade, rH['labels']):>20.3f}")
    print("\nlast column: accuracy at recovering sibling PAIRS rather than "
          "individuals -\nwhen worms fuse, the clade structure is still correct.")
