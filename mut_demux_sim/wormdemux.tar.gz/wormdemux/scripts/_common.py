"""Shared helpers for the experiment scripts."""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def base_parser(desc):
    p = argparse.ArgumentParser(description=desc)
    p.add_argument("--worms", type=int, default=10)
    p.add_argument("--cells", type=int, default=60, help="cells per worm")
    p.add_argument("--breadth", type=float, default=0.25)
    p.add_argument("--seed", type=int, default=0)
    return p


def header(cols, widths):
    return "".join(f"{c:>{w}}" for c, w in zip(cols, widths))
