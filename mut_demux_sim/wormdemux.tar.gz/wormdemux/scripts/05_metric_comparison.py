#!/usr/bin/env python3
"""Does the choice of binary distance metric matter?

Hamming, Jaccard and phi differ in whether co-absence counts as evidence.
With an intermediate-frequency site panel they are near-identical; phi is the
principled default because it discounts co-absence against marginal frequency
and degrades more gracefully if the site panel drifts toward rare variants.
"""
from _common import base_parser, header
from sklearn.metrics import adjusted_rand_score
from wormdemux import simulate_pool, demultiplex

METRICS = ["hamming", "jaccard", "phi", "corr"]

if __name__ == "__main__":
    p = base_parser(__doc__)
    p.add_argument("--germline", type=int, default=200)
    a = p.parse_args()
    cases = [("clean", dict()),
             ("somatic 4x", dict(somatic_per_worm=a.germline * 4)),
             ("somatic 4x + 2% FP", dict(somatic_per_worm=a.germline * 4, fp_rate=0.02)),
             ("sparse (breadth 0.05)", dict(breadth=0.05))]
    print(header(["scenario"] + METRICS, [24] + [10] * len(METRICS)))
    for label, kw in cases:
        kw.setdefault("breadth", a.breadth)
        d = simulate_pool(n_worms=a.worms, cells_per_worm=a.cells,
                          germline_per_worm=a.germline, seed=a.seed, **kw)
        row = ""
        for m in METRICS:
            r = demultiplex(d["AD"], d["DP"], K=a.worms, frac_lo=0.005, metric=m)
            row += f"{adjusted_rand_score(d['truth'], r['labels']):>10.3f}"
        print(f"{label:>24}{row}")
