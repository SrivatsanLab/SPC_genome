#!/usr/bin/env python3
"""Do somatic mutations break demultiplexing, and does site filtering help?

Somatic mutations create nested clonal sub-structure inside each worm. They add
within-worm distance but never pull two worms together, so they are tolerated
until they overwhelm the germline signal. The carrier-fraction filter rescues
one regime but cannot manufacture signal that is not there.
"""
from _common import base_parser, header
from sklearn.metrics import adjusted_rand_score
from wormdemux import simulate_pool, demultiplex

LOADS = [(300, 300), (100, 800), (30, 1500), (10, 2000), (3, 2500)]

if __name__ == "__main__":
    p = base_parser(__doc__)
    p.add_argument("--filter-lo", type=float, default=None,
                   help="carrier-fraction floor for the filtered column "
                        "(default: 0.7/n_worms, just below the germline peak)")
    a = p.parse_args()
    lo = a.filter_lo if a.filter_lo is not None else 0.7 / a.worms
    print(f"germline peak expected at 1/{a.worms} = {1/a.worms:.3f}; "
          f"filter floor = {lo:.3f}\n")
    print(header(["germline/worm", "somatic/worm", "no filter", f"frac>{lo:.2f}"],
                 [15, 15, 12, 12]))
    for germ, som in LOADS:
        d = simulate_pool(n_worms=a.worms, cells_per_worm=a.cells,
                          germline_per_worm=germ, somatic_per_worm=som,
                          breadth=a.breadth, seed=a.seed)
        r1 = demultiplex(d["AD"], d["DP"], K=a.worms, frac_lo=0.0005)
        r2 = demultiplex(d["AD"], d["DP"], K=a.worms, frac_lo=lo)
        print(f"{germ:>15}{som:>15}"
              f"{adjusted_rand_score(d['truth'], r1['labels']):>12.3f}"
              f"{adjusted_rand_score(d['truth'], r2['labels']):>12.3f}")
