#!/usr/bin/env python3
"""How many de novo mutations per lineage are needed to demultiplex?

Sweeps germline mutations per worm from wild-type-like loads to hypermutator
loads and reports clustering accuracy. This is the experiment that decides
feasibility: below roughly 50 mutations per lineage the information is not
present, and no method or parameter choice recovers it.
"""
from _common import base_parser, header
import numpy as np
from sklearn.metrics import adjusted_rand_score
from wormdemux import simulate_pool, demultiplex, select_sites, binary_matrices

REGIMES = [(5, "wild-type, ~15 generations"), (15, "wild-type, ~50 generations"),
           (50, "mild elevation"), (200, "hypermutator"),
           (1000, "strong hypermutator")]

if __name__ == "__main__":
    a = base_parser(__doc__).parse_args()
    print(header(["mut/lineage", "regime", "sites", "shared/pair", "ARI"],
                 [13, 28, 8, 13, 8]))
    for mpl, label in REGIMES:
        d = simulate_pool(n_worms=a.worms, cells_per_worm=a.cells,
                          germline_per_worm=mpl, breadth=a.breadth, seed=a.seed)
        idx = select_sites(d["AD"], d["DP"], frac_lo=0.005)
        if len(idx) < 10:
            print(f"{mpl:>13}{label:>28}{len(idx):>8}{'-':>13}{'n/a':>8}")
            continue
        _, M = binary_matrices(d["AD"], d["DP"], idx)
        shared = np.median((M @ M.T)[~np.eye(len(M), dtype=bool)])
        r = demultiplex(d["AD"], d["DP"], K=a.worms, frac_lo=0.005)
        ari = adjusted_rand_score(d["truth"], r["labels"])
        print(f"{mpl:>13}{label:>28}{len(idx):>8}{shared:>13.0f}{ari:>8.3f}")
