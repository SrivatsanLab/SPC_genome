#!/usr/bin/env python3
"""Why is the observed within-group correlation lower than expected?

For homozygous worms with clean calls, within-worm correlation should be ~0.95.
Three things pull it down: somatic mutations (real within-worm discordance),
false-positive calls, and unfixed heterozygous germline variants (a coin flip
per read at low depth). The cross-worm baseline stays near -1/(K-1) throughout,
so the within/cross GAP - what clustering actually uses - is preserved.
"""
from _common import base_parser, header
from wormdemux import simulate_pool, select_sites, corr_masked, within_cross

SCENARIOS = [
    ("germline only, no error",     dict()),
    ("+ somatic 2x germline",       dict(somatic_per_worm=None, mult=2)),
    ("+ somatic 6x germline",       dict(somatic_per_worm=None, mult=6)),
    ("+ 2% false-positive calls",   dict(somatic_per_worm=None, mult=2, fp_rate=0.02)),
    ("+ 30% unfixed (het) germline", dict(somatic_per_worm=None, mult=2, het_frac=0.30)),
]

if __name__ == "__main__":
    p = base_parser(__doc__)
    p.add_argument("--germline", type=int, default=2000)
    a = p.parse_args()
    print(header(["scenario", "panel", "sites", "within", "cross", "gap"],
                 [32, 16, 8, 9, 9, 8]))
    for label, kw in SCENARIOS:
        mult = kw.pop("mult", 0)
        kw.pop("somatic_per_worm", None)
        d = simulate_pool(n_worms=a.worms, cells_per_worm=a.cells,
                          germline_per_worm=a.germline,
                          somatic_per_worm=a.germline * mult,
                          breadth=a.breadth, seed=a.seed, **kw)
        for lo, panel in [(0.0005, "all sites"), (0.7 / a.worms, "germline band")]:
            idx = select_sites(d["AD"], d["DP"], frac_lo=lo)
            C, _ = corr_masked(d["AD"], d["DP"], idx)
            wc = within_cross(C, d["truth"])
            print(f"{label:>32}{panel:>16}{len(idx):>8}"
                  f"{wc['within']:>9.3f}{wc['cross']:>+9.3f}{wc['gap']:>8.3f}")
