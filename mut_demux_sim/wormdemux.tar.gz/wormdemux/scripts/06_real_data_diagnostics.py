#!/usr/bin/env python3
"""Run the feasibility diagnostics on a real AnnData file.

    python 06_real_data_diagnostics.py mydata.h5ad --K 20 --plot carrier.png

Expects layers 'AD' (alt depth) and 'DP' (total depth); dense or sparse.
Prints the site-class breakdown and the shared-sites-per-pair number that
determines feasibility, and optionally writes the carrier-fraction histogram.
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from wormdemux import feasibility_report, plot_carrier_fraction

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("h5ad")
    p.add_argument("--K", type=int, default=None, help="expected number of donors")
    p.add_argument("--ad-layer", default="AD")
    p.add_argument("--dp-layer", default="DP")
    p.add_argument("--frac-lo", type=float, default=0.03)
    p.add_argument("--frac-hi", type=float, default=0.97)
    p.add_argument("--plot", default=None, help="path for the carrier-fraction figure")
    a = p.parse_args()

    import anndata as ad
    adata = ad.read_h5ad(a.h5ad)
    AD, DP = adata.layers[a.ad_layer], adata.layers[a.dp_layer]
    print(f"{adata.n_obs} cells x {adata.n_vars} sites\n")
    feasibility_report(AD, DP, K=a.K, frac_lo=a.frac_lo, frac_hi=a.frac_hi)
    if a.plot:
        import matplotlib; matplotlib.use("Agg")
        plot_carrier_fraction(AD, DP, K=a.K, out=a.plot)
        print(f"\nwrote {a.plot}")
